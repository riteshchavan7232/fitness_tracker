let soundEnabled = false;
const reminderSound = new Audio("assets/notification.wav");

function enableReminders() {
  reminderSound.play()
    .then(() => {
      reminderSound.pause();
      reminderSound.currentTime = 0;
      soundEnabled = true;
      sessionStorage.setItem("soundEnabled", "true");
      const btn = document.getElementById("reminderBtn");
      if (btn) btn.style.display = "none";
    })
    .catch((err) => {
      console.warn("User interaction needed to enable sound:", err);
      alert("Please click to enable sound and notifications.");
    });

  if ('Notification' in window && Notification.permission !== "granted") {
    Notification.requestPermission();
  }
}

function showNotification(message) {
  let playCount = 0;
  const maxPlays = 20;
  const playInterval = setInterval(() => {
    if (soundEnabled) {
      reminderSound.currentTime = 0;
      reminderSound.play().catch(console.error);
    }
    playCount++;
    if (playCount >= maxPlays) clearInterval(playInterval);
  }, 3000);

  const options = {
    body: message,
    icon: 'assets/fitness-icon.png',
    badge: 'assets/badge-icon.png',
    vibrate: [200, 100, 200],
    tag: 'fitness-reminder',
    requireInteraction: true
  };

  if (Notification.permission === "granted") {
    const notif = new Notification("🏋️ Fitness Tracker Reminder", options);
    notif.onclose = () => clearInterval(playInterval);
    setTimeout(() => {
      notif.close();
      clearInterval(playInterval);
    }, 60000);
  } else {
    alert("Reminder: " + message);
    clearInterval(playInterval);
  }
}

function checkReminders() {
  const now = new Date();
  const currentTime = now.toTimeString().slice(0, 5);
  const seconds = now.getSeconds();
  if (seconds !== 0) return;

  let reminders = JSON.parse(localStorage.getItem("reminders")) || [];
  reminders.forEach((r, i) => {
    if (r.time === currentTime) {
      showNotification(r.message);
      reminders.splice(i, 1);
    }
  });
  localStorage.setItem("reminders", JSON.stringify(reminders));
}

// Load saved setting
if (sessionStorage.getItem("soundEnabled") === "true") {
  soundEnabled = true;
}

// Start reminder engine
window.addEventListener("load", () => {
  if ('Notification' in window && Notification.permission !== "granted") {
    Notification.requestPermission();
  }
  setInterval(checkReminders, 1000);
});
