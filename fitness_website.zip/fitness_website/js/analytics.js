const weeksToShow = 4;
const now = new Date();

function getPastWeekRanges() {
  const weeks = [];
  for (let i = weeksToShow - 1; i >= 0; i--) {
    const start = new Date(now);
    start.setDate(now.getDate() - now.getDay() - i * 7);
    const end = new Date(start);
    end.setDate(start.getDate() + 6);
    weeks.push({
      label: `Week ${weeksToShow - i}`,
      startDate: start.toISOString().split("T")[0],
      endDate: end.toISOString().split("T")[0],
    });
  }
  return weeks;
}

function isDateInRange(dateStr, start, end) {
  return dateStr >= start && dateStr <= end;
}

function calculateWeeklyData() {
  const weeks = getPastWeekRanges();
  const activities = JSON.parse(localStorage.getItem("activities")) || [];
  const waterData = JSON.parse(localStorage.getItem("waterIntakeData")) || {};

  const caloriesPerWeek = Array(weeksToShow).fill(0);
  const workoutsPerWeek = Array(weeksToShow).fill(0);
  const waterPerWeek = Array(weeksToShow).fill(0);

  activities.forEach((act) => {
    weeks.forEach((week, idx) => {
      if (isDateInRange(act.date, week.startDate, week.endDate)) {
        workoutsPerWeek[idx]++;
        caloriesPerWeek[idx] += getCalories(act.type, act.duration);
      }
    });
  });

  Object.keys(waterData).forEach((date) => {
    weeks.forEach((week, idx) => {
      if (isDateInRange(date, week.startDate, week.endDate)) {
        waterPerWeek[idx] += parseFloat(waterData[date]) || 0;
      }
    });
  });

  return {
    labels: weeks.map((w) => w.label),
    caloriesPerWeek,
    workoutsPerWeek,
    waterPerWeek,
  };
}

function getCalories(type, duration) {
  const rates = {
    running: 10,
    cycling: 8,
    walking: 4,
    gym: 7,
    yoga: 3,
  };
  return (rates[type.toLowerCase()] || 5) * parseInt(duration);
}

function createBarChart(ctxId, labels, data, label, bgColor) {
  new Chart(document.getElementById(ctxId), {
    type: "bar",
    data: {
      labels: labels,
      datasets: [{
        label: label,
        data: data,
        backgroundColor: bgColor,
        borderRadius: 10,
        borderSkipped: false,
      }],
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false },
        tooltip: { mode: 'index', intersect: false },
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: { stepSize: 1 },
        },
      },
    },
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const { labels, caloriesPerWeek, workoutsPerWeek, waterPerWeek } = calculateWeeklyData();

  createBarChart("caloriesChart", labels, caloriesPerWeek, "Calories Burned", "#ff6b6b");
  createBarChart("waterChart", labels, waterPerWeek, "Water Intake (L)", "#4dc9f6");
  createBarChart("workoutsChart", labels, workoutsPerWeek, "Workouts", "#34c38f");
});
