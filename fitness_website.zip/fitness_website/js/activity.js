const form = document.getElementById('activityForm');
const activityList = document.getElementById('activityData');

// Load session data when the page loads
window.onload = () => {
  const saved = JSON.parse(sessionStorage.getItem('activities')) || [];
  saved.forEach(addToDOM);
};

// Handle form submit
form.addEventListener('submit', function (e) {
  e.preventDefault();

  const type = document.getElementById('type').value;
  const duration = document.getElementById('duration').value;
  const date = document.getElementById('date').value;

  const activity = {
    type,
    duration,
    date
  };
  const activities = JSON.parse(sessionStorage.getItem('activities')) || [];
  activities.push(activity);
  sessionStorage.setItem('activities', JSON.stringify(activities));

  addToDOM(activity);
  form.reset();
});

function addToDOM(activity) {
  const li = document.createElement('li');
  li.textContent = `${activity.date} - ${activity.type} (${activity.duration} mins)`;
  activityList.appendChild(li);
}
